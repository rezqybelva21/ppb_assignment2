import 'package:objectbox/objectbox.dart';

@Entity()
class Car {
  @Id()
  int id = 0;

  String name;
  String image;
  String description;
  String engineType;
  String mileage;
  String price;
  String transmission;

  Car({
    this.id = 0,
    required this.name,
    required this.image,
    required this.description,
    required this.engineType,
    required this.mileage,
    required this.price,
    required this.transmission,
  });
}

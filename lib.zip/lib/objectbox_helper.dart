import 'package:objectbox/objectbox.dart' show Store;
import 'objectbox.g.dart'; // auto-generated file
import 'models/car_model.dart';

class ObjectBoxHelper {
  late final Store store;
  late final Box<Car> carBox;
  Admin? _admin;

  ObjectBoxHelper._create(this.store) {
    carBox = store.box<Car>();

    if (Admin.isAvailable()) {
      _admin = Admin(store);
      print('✅ ObjectBox Admin berjalan di http://127.0.0.1:8090');
    }
  }

  static Future<ObjectBoxHelper> create() async {
    final store = await openStore();
    return ObjectBoxHelper._create(store);
  }

  void close() {
    _admin?.close();
    store.close();
  }
}

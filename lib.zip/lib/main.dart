import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:objectbox/objectbox.dart';
import 'objectbox_helper.dart';
import 'objectbox.g.dart';
import 'models/car_model.dart';




void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final objectbox = await ObjectBoxHelper.create();
  runApp(MyApp(objectbox: objectbox));
}

class MyApp extends StatelessWidget {
  final ObjectBoxHelper objectbox;

  const MyApp({super.key, required this.objectbox});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Catalog Mobil',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: CarCatalogScreen(objectbox: objectbox),
    );
  }
}

class CarCatalogScreen extends StatefulWidget {
  final ObjectBoxHelper objectbox;

  const CarCatalogScreen({super.key, required this.objectbox});

  @override
  _CarCatalogScreenState createState() => _CarCatalogScreenState();
}

class _CarCatalogScreenState extends State<CarCatalogScreen> {
  late Box<Car> _carBox;
  List<Car> _cars = [];

  @override
  void initState() {
    super.initState();
    _carBox = widget.objectbox.carBox;
    _cars = _carBox.getAll();
  }

  void _addCar(Car car) {
    _carBox.put(car);
    setState(() {
      _cars = _carBox.getAll();
    });
  }

  void _updateCar(int index, Car updatedCar) {
    updatedCar.id = _cars[index].id;
    _carBox.put(updatedCar);
    setState(() {
      _cars = _carBox.getAll();
    });
  }

  void _removeCar(int index) {
    _carBox.remove(_cars[index].id);
    setState(() {
      _cars = _carBox.getAll();
    });
  }

  void _showAddCarDialog() {
    final nameController = TextEditingController();
    final imageController = TextEditingController();
    final descriptionController = TextEditingController();
    final engineTypeController = TextEditingController();
    final mileageController = TextEditingController();
    final priceController = TextEditingController();
    final transmissionController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Tambah Mobil Baru'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Nama')),
                TextField(controller: imageController, decoration: const InputDecoration(labelText: 'URL Gambar')),
                TextField(controller: descriptionController, decoration: const InputDecoration(labelText: 'Deskripsi')),
                TextField(controller: engineTypeController, decoration: const InputDecoration(labelText: 'Tipe Mesin')),
                TextField(controller: mileageController, decoration: const InputDecoration(labelText: 'Mileage')),
                TextField(controller: priceController, decoration: const InputDecoration(labelText: 'Harga')),
                TextField(controller: transmissionController, decoration: const InputDecoration(labelText: 'Transmisi')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
            TextButton(
              onPressed: () {
                _addCar(Car(
                  name: nameController.text,
                  image: imageController.text,
                  description: descriptionController.text,
                  engineType: engineTypeController.text,
                  mileage: mileageController.text,
                  price: priceController.text,
                  transmission: transmissionController.text,
                ));
                Navigator.pop(context);
              },
              child: const Text('Tambahkan'),
            ),
          ],
        );
      },
    );
  }

  void _showEditCarDialog(int index) {
    final car = _cars[index];
    final nameController = TextEditingController(text: car.name);
    final imageController = TextEditingController(text: car.image);
    final descriptionController = TextEditingController(text: car.description);
    final engineTypeController = TextEditingController(text: car.engineType);
    final mileageController = TextEditingController(text: car.mileage);
    final priceController = TextEditingController(text: car.price);
    final transmissionController = TextEditingController(text: car.transmission);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Mobil'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Nama')),
                TextField(controller: imageController, decoration: const InputDecoration(labelText: 'URL Gambar')),
                TextField(controller: descriptionController, decoration: const InputDecoration(labelText: 'Deskripsi')),
                TextField(controller: engineTypeController, decoration: const InputDecoration(labelText: 'Tipe Mesin')),
                TextField(controller: mileageController, decoration: const InputDecoration(labelText: 'Mileage')),
                TextField(controller: priceController, decoration: const InputDecoration(labelText: 'Harga')),
                TextField(controller: transmissionController, decoration: const InputDecoration(labelText: 'Transmisi')),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
            TextButton(
              onPressed: () {
                _updateCar(index, Car(
                  name: nameController.text,
                  image: imageController.text,
                  description: descriptionController.text,
                  engineType: engineTypeController.text,
                  mileage: mileageController.text,
                  price: priceController.text,
                  transmission: transmissionController.text,
                ));
                Navigator.pop(context);
              },
              child: const Text('Simpan'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    List<String> carouselImages = _cars.map((car) => car.image).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Used Car Dealership')),
      body: Stack(
        children: [
          Column(
            children: [
              if (carouselImages.isNotEmpty)
                CarouselSlider(
                  options: CarouselOptions(height: 200.0, autoPlay: true, enlargeCenterPage: true),
                  items: carouselImages.map((image) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 5.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Image.network(
                          image,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.grey[300],
                              child: const Icon(Icons.error, color: Colors.red),
                            );
                          },
                        ),
                      ),
                    );
                  }).toList(),
                ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: _cars.length,
                  itemBuilder: (context, index) {
                    final car = _cars[index];
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CarDetailScreen(car: car)),
                      ),
                      child: Card(
                        elevation: 4,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  car.image,
                                  width: 80,
                                  height: 80,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      width: 80,
                                      height: 80,
                                      color: Colors.grey[300],
                                      child: const Icon(Icons.error, color: Colors.red),
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(car.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                    const SizedBox(height: 5),
                                    Text(car.description, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
                                    Text('Engine: ${car.engineType}'),
                                    Text('Mileage: ${car.mileage}'),
                                    Text('Price: \$${car.price}', style: const TextStyle(color: Colors.green)),
                                    Text('Transmission: ${car.transmission}'),
                                  ],
                                ),
                              ),
                              Column(
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.blue),
                                    onPressed: () => _showEditCarDialog(index),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red),
                                    onPressed: () => _removeCar(index),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 16,
            child: Center(
              child: ElevatedButton.icon(
                onPressed: _showAddCarDialog,
                icon: const Icon(Icons.add),
                label: const Text('Add Car'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CarDetailScreen extends StatelessWidget {
  final Car car;
  const CarDetailScreen({super.key, required this.car});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(car.name)),
      body: SingleChildScrollView(
        child: Column(
          children: [
            CarouselSlider(
              options: CarouselOptions(height: 250.0, enableInfiniteScroll: false),
              items: [car.image].map((image) {
                return Container(
                  margin: const EdgeInsets.all(5.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Image.network(
                      image,
                      fit: BoxFit.cover,
                      width: 1000.0,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          width: double.infinity,
                          height: 250,
                          color: Colors.grey[300],
                          child: const Icon(Icons.error, color: Colors.red),
                        );
                      },
                    ),
                  ),
                );
              }).toList(),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(car.description),
                  const SizedBox(height: 10),
                  Text('Engine Type: ${car.engineType}'),
                  Text('Mileage: ${car.mileage}'),
                  Text('Price: \$${car.price}', style: const TextStyle(color: Colors.green)),
                  Text('Transmission: ${car.transmission}'),
                  const SizedBox(height: 20),
                  ElevatedButton(onPressed: () {}, child: const Text('Contact Dealership')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
